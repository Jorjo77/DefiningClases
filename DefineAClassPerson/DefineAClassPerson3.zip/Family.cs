﻿using DefiningClasses;
using System;
using System.Collections.Generic;
using System.Text;

namespace DefineAClassPerson
{
    public class Family
    {
        public Family()
        {
            People = new List<Person>();
        }
        public List<Person> People { get; set; }

        public void AddMember(Person member)
        {
            People.Add(member);
        }

        public Person GetOldestMember()
        {
            int maxAge = int.MinValue;
            Person oldestPerson = null;
            // 1 foreach/ min max value
            //2 linq
            foreach (var person in People)
            {
                var currentAge = person.Age;
                if (currentAge>maxAge)
                {
                    maxAge = currentAge;
                    oldestPerson = person;
                }
            }
            return oldestPerson;
        }
    }
}
